/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.virtual.model;


import org.hibernate.SessionFactory;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;

/**
 *
 * @author srki
 */
public class HibernateUtil {
    
   
    //SessionFactory clasa i instance koja mora da bude globalna 
        
        private static SessionFactory sessionFactory;
        public static SessionFactory getFactory(){
            //potrebno je staviti uslov da samo ako nema klase vec napravljene odnono Sessionfacrtory =null da se
            //pristupi pravljnju nove klase
            //kad refresujemo stranu vise puta nesmemo da dobijemo drugaciji hashcode moramo dobijati uvek isti hash iliklasu
            if(sessionFactory==null){
            Configuration config=new Configuration();
           // config.setProperty("hibernate.connection.username","root");mozemo i odavde iz jave konfigurisati 
            //hibernate.cfg ali to nema potrebe jer je vec uradjeno 
           
            config.configure();//ovaj metod samo kaze da se konfigruise vec postojeci fajl tj da bude prepoznat od hibernate
           
       /*ovo je duzi nacin za pravljenje Service Registry-ja
            ServiceRegistry serviceRegistry;
            StandardServiceRegistryBuilder srb=new StandardServiceRegistryBuilder();
            //ovaj deo koda dobavalja podesavanja iz config,configure()
            srb.applySettings(config.getProperties());
            serviceRegistry=srb.build();
               */
       /*ovo je kraci nacin iz jednog reda*/
       ServiceRegistry serviceRegistry=new StandardServiceRegistryBuilder().applySettings(config.getProperties()).build();
       
            sessionFactory=config.buildSessionFactory(serviceRegistry);
            }
        return sessionFactory;
        
        }
        
    
}
