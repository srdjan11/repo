/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.virtual.manage;

import com.virtual.model.Machine;
import java.util.Date;

/**
 *
 * @author root
 */
public class MachineManager {
    
    

    
    
    public static Machine getFilters(){
            Machine m=new Machine();
    String uid=m.getUid();
    String status=m.getStatus();
    Date createdat=m.getCreatedAt();
    short getactive=m.getActive();
    return m;
    }
}
