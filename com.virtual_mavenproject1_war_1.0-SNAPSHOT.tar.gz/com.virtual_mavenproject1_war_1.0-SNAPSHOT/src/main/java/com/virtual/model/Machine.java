/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.virtual.model;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author root
 */
@Entity
@Table(name = "machine")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Machine.findAll", query = "SELECT m FROM Machine m"),
    @NamedQuery(name = "Machine.findByMachineId", query = "SELECT m FROM Machine m WHERE m.machineId = :machineId"),
    @NamedQuery(name = "Machine.findByUid", query = "SELECT m FROM Machine m WHERE m.uid = :uid"),
    @NamedQuery(name = "Machine.findByStatus", query = "SELECT m FROM Machine m WHERE m.status = :status"),
    @NamedQuery(name = "Machine.findByCreatedAt", query = "SELECT m FROM Machine m WHERE m.createdAt = :createdAt"),
    @NamedQuery(name = "Machine.findByActive", query = "SELECT m FROM Machine m WHERE m.active = :active")})
public class Machine implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "machine_id")
    private Integer machineId;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 100)
    @Column(name = "uid")
    private String uid;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 45)
    @Column(name = "status")
    private String status;
    @Basic(optional = false)
    @NotNull
    @Column(name = "createdAt")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdAt;
    @Basic(optional = false)
    @NotNull
    @Column(name = "active")
    private short active;
    @JoinColumn(name = "fk_createdBy", referencedColumnName = "id")
    @ManyToOne(optional = false)
    private User fkcreatedBy;

    public Machine() {
    }

    public Machine(Integer machineId) {
        this.machineId = machineId;
    }

    public Machine(Integer machineId, String uid, String status, Date createdAt, short active) {
        this.machineId = machineId;
        this.uid = uid;
        this.status = status;
        this.createdAt = createdAt;
        this.active = active;
    }

    public Integer getMachineId() {
        return machineId;
    }

    public void setMachineId(Integer machineId) {
        this.machineId = machineId;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }

    public short getActive() {
        return active;
    }

    public void setActive(short active) {
        this.active = active;
    }

    public User getFkcreatedBy() {
        return fkcreatedBy;
    }

    public void setFkcreatedBy(User fkcreatedBy) {
        this.fkcreatedBy = fkcreatedBy;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (machineId != null ? machineId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Machine)) {
            return false;
        }
        Machine other = (Machine) object;
        if ((this.machineId == null && other.machineId != null) || (this.machineId != null && !this.machineId.equals(other.machineId))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.virtual.model.Machine[ machineId=" + machineId + " ]";
    }
    
}
