/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.virtual.model;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author root
 */
@Entity
@Table(name = "Filters")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Filters.findAll", query = "SELECT f FROM Filters f"),
    @NamedQuery(name = "Filters.findByFilterId", query = "SELECT f FROM Filters f WHERE f.filterId = :filterId"),
    @NamedQuery(name = "Filters.findByStatus", query = "SELECT f FROM Filters f WHERE f.status = :status"),
    @NamedQuery(name = "Filters.findByDateFrom", query = "SELECT f FROM Filters f WHERE f.dateFrom = :dateFrom"),
    @NamedQuery(name = "Filters.findByDateTo", query = "SELECT f FROM Filters f WHERE f.dateTo = :dateTo")})
public class Filters implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "filter_id")
    private Integer filterId;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 45)
    @Column(name = "status")
    private String status;
    @Basic(optional = false)
    @NotNull
    @Column(name = "dateFrom")
    @Temporal(TemporalType.DATE)
    private Date dateFrom;
    @Basic(optional = false)
    @NotNull
    @Column(name = "dateTo")
    @Temporal(TemporalType.DATE)
    private Date dateTo;

    public Filters() {
    }

    public Filters(Integer filterId) {
        this.filterId = filterId;
    }

    public Filters(Integer filterId, String status, Date dateFrom, Date dateTo) {
        this.filterId = filterId;
        this.status = status;
        this.dateFrom = dateFrom;
        this.dateTo = dateTo;
    }

    public Integer getFilterId() {
        return filterId;
    }

    public void setFilterId(Integer filterId) {
        this.filterId = filterId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Date getDateFrom() {
        return dateFrom;
    }

    public void setDateFrom(Date dateFrom) {
        this.dateFrom = dateFrom;
    }

    public Date getDateTo() {
        return dateTo;
    }

    public void setDateTo(Date dateTo) {
        this.dateTo = dateTo;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (filterId != null ? filterId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Filters)) {
            return false;
        }
        Filters other = (Filters) object;
        if ((this.filterId == null && other.filterId != null) || (this.filterId != null && !this.filterId.equals(other.filterId))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.virtual.model.Filters[ filterId=" + filterId + " ]";
    }
    
}
